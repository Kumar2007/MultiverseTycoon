MULTIVERSE TYCOON - WINDOWS INSTRUCTIONS
====================================

Requirements:
- Python 3.6 or higher must be installed
- Dependencies: None (standard library only)

To run the game:
1. Double-click run_game.bat
   OR
2. Open a command prompt in this folder and type:
   python multiverse_tycoon.py

Enjoy your multiverse business adventures!
