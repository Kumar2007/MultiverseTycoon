MULTIVERSE TYCOON - LINUX INSTRUCTIONS
==================================

Requirements:
- Python 3.6 or higher must be installed
- Dependencies: None (standard library only)

To run the game:
1. Open Terminal in this folder
2. Type: chmod +x run_game.sh (first time only)
3. Type: ./run_game.sh
   OR
4. Type: python3 multiverse_tycoon.py

Enjoy your multiverse business adventures!
