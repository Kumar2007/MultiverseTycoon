#!/bin/bash
echo "Starting Multiverse Tycoon..."
python3 multiverse_tycoon.py
